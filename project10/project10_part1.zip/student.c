/*
This file contain the implementatino of functions declared in student.h
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

void help() {
	printf("List of operation codes:\n");
	printf("\t'h' for help;\n");
	printf("\t'a' for adding a student to the queue;\n");
	printf("\t'p' for removing a student from the queue;\n");
	printf("\t'l' for listing all students in the queue;\n");
	printf("\t'g' for searching students with a minimum GPA;\n");
	printf("\t'c' for searching students with a minimum grade in COP2510;\n");
	printf("\t'q' to quit.\n");
}

void read(char *name, char *netid, char *cop2510_grade, double *gpa, int *attempts) {
	if(name != NULL) {
		printf("Enter the name of the student: ");
		scanf("%[^\n]", name);
	}
	if(netid != NULL) {
		printf("Enter the NetID of the student: ");
		scanf("%s", netid);
	}
	if(cop2510_grade != NULL) {
		printf("Enter the COP2510 letter grade: ");
		scanf(" %c", cop2510_grade);
	}
	if(gpa != NULL) {
		printf("Enter the GPA: ");
		scanf("%lf", gpa);
	}
	if(attempts != NULL) {
		printf("Enter the number of previous attempts: ");
		scanf("%d", attempts);
	}
}

/////////////////////////////////////////////////////////
// WARNING - WARNING - WARNING - WARNING - WARNING     //
/////////////////////////////////////////////////////////
// Do not modify anything before this point, otherwise //
// your solution will be considered incorrect.         //
/////////////////////////////////////////////////////////

/*
add_student:
-recives the registration linked list and the values for student name, netid, cop2510 grade, gpa,
and number of previous attemps, and ads the new students to the reigstration linked list
so that the nodes in the list are kept in order by number of previous atteps in decreasing order; 
students with the same number of previous attemps are inserted in first come, first serve basis;
-this function returns a pointer to the updated queue;
*/

struct student * add_student(struct student *registration, char *name, char *netid, char cop2510_grade, double gpa, int attempts) {
	struct student *new_student;
	new_student = malloc(sizeof(struct student));
	if(new_student == NULL){
		printf("malloc faiiled in add_student\n");
		return registration;
	}
	//strings
	strcpy(new_student ->name, name);
	strcpy(new_student ->netid, netid);
	new_student -> cop2510_grade = cop2510_grade;
	//numbers
	new_student -> gpa = gpa;
	new_student ->  attempts = attempts;
	new_student -> next = NULL;


	//if the list is empty, new student first come, first serve
	if(registration == NULL){
		return new_student;
	}
	//decreasing order
	struct student *old_student = NULL, *current_student = registration;
    while (current_student != NULL && current_student->attempts > attempts) {
        old_student = current_student;
        current_student = current_student->next;
    }

    //if the current student has the same number of attempts, first-come-first-serve
    while (current_student != NULL && current_student->attempts == attempts) {
        old_student = current_student;
        current_student = current_student->next;
    }

    //insert the new student
    if (old_student == NULL) {
        new_student->next = registration;
        registration = new_student;
    } else {
        old_student->next = new_student;
        new_student->next = current_student;
    }

    return registration;

}

/*
pop_student: receives the registration linked list, prints the information of the next student to be registered (first come, first serve basis), 
and removes it from the queue; if the queue is empty, this function does nothing; this function returns a pointer to the updated queue;
*/

struct student * pop_student(struct student *registration) {

	//if the queue is empty
	if(registration == NULL) return NULL;

	struct student *p = registration;
	
	// output format
	printf("|----------------------|----------------------|---------|-----|----------|\n");
	printf("| Name                 | NetID                | COP2510 | GPA | Attempts |\n");
	printf("|----------------------|----------------------|---------|-----|----------|\n");
	printf("| %-20s | %-20s |       %c | %1.1f | %8d |\n", p -> name, p -> netid, p -> cop2510_grade, p -> gpa, p -> attempts);
	printf("|----------------------|----------------------|---------|-----|----------|\n");

	registration = registration -> next;

	free(p);


	return registration;
}

/*
list_students: receives the registration linked list and lists all students in it; 
if the queue is empty, this function does nothing;
*/
void list_students(struct student *registration) {
	if(registration == NULL) return;

	struct student *p;
	{

	// output format
		printf("|----------------------|----------------------|---------|-----|----------|\n");
		printf("| Name                 | NetID                | COP2510 | GPA | Attempts |\n");
		printf("|----------------------|----------------------|---------|-----|----------|\n");
		for(p = registration; p != NULL; p = p -> next){
			printf("| %-20s | %-20s |       %c | %1.1f | %8d |\n", p -> name, p -> netid, p -> cop2510_grade, p -> gpa, p -> attempts);
			printf("|----------------------|----------------------|---------|-----|----------|\n");
		}
	}
	// ...
}
/*
list_gpa_min: receives the registration linked list and a minimum GPA value, 
lists all students in the list that satisfy this condition; 
if no students satisfy this condition, this function does nothing;*/
void list_gpa_min(struct student *registration, double gpa) {
    struct student *p = registration;
    int found = 0;

    for (p = registration; p != NULL; p = p->next) {
        if (p->gpa >= gpa) {
            if (!found) {
                printf("|----------------------|----------------------|---------|-----|----------|\n");
                printf("| Name                 | NetID                | COP2510 | GPA | Attempts |\n");
                printf("|----------------------|----------------------|---------|-----|----------|\n");
            }
            printf("| %-20s | %-20s |       %c | %1.1f | %8d |\n", p->name, p->netid, p->cop2510_grade, p->gpa, p->attempts);
            printf("|----------------------|----------------------|---------|-----|----------|\n");
            found = 1;
        }
    }

    if (!found) {

    }
}

/*
list_cop2510_min: receives the registration linked list and a minimum COP2510 grade, 
lists all students in the list that satisfy this condition; 
if no students satisfy this condition, this function does nothing;*/
void list_cop2510_min(struct student *registration, int cop2510_grade) {

	struct student *p = registration;
	int found = 0;

	for(p = registration; p != NULL; p = p -> next){
		if(p -> cop2510_grade <= cop2510_grade){
			if(!found){
				printf("|----------------------|----------------------|---------|-----|----------|\n");
				printf("| Name                 | NetID                | COP2510 | GPA | Attempts |\n");
				printf("|----------------------|----------------------|---------|-----|----------|\n");
			}
			printf("| %-20s | %-20s |       %c | %1.1f | %8d |\n", p -> name, p -> netid, p -> cop2510_grade, p -> gpa, p -> attempts);
			printf("|----------------------|----------------------|---------|-----|----------|\n");
			found = 1;
		}
	}
	if(!found){

	}
}
/*
clear_queue: receives the registration linked list and deletes all students in it; 
this function returns a pointer to the updated queue.
*/
struct student * clear_queue(struct student *registration) {

	struct student *p;
	while(registration != NULL)
	{
		p = registration;
		registration = registration -> next;
		if(p != NULL)
			free(p);
	}
	return registration;
}
